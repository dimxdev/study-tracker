# Project.md — Personal Learning & Task Tracker

## Nama Project (sementara)
**Crawl** — terinspirasi dari motto pemilik project: *"I may be slow, but I never stop crawling forward 🐢"*
(Boleh diganti kapan saja, ini cuma nama kerja/codename)

## Overview
Web app personal untuk mencatat, melacak, dan mengelola daftar hal-hal yang ingin dipelajari atau dikerjakan (misalnya: teknologi baru, project pribadi, skill). Ketika bingung "abis ini ngapain ya", user tinggal buka web ini, lihat daftarnya, dan lanjutkan progress dari sana.

## Masalah yang Diselesaikan
- Susah tracking banyak hal yang ingin dipelajari/dikerjakan secara bersamaan
- Gampang lupa progress terakhir ada di mana
- Butuh motivasi visual biar konsisten belajar/ngerjain sesuatu secara bertahap

## Target User
Personal use — 1 user (pemilik project), tidak perlu sistem multi-user/login.

## Tech Stack
- **Framework**: Next.js (App Router)
- **Styling**: Tailwind CSS
- **State/Data**: Full frontend, **localStorage** sebagai satu-satunya penyimpanan data (tidak ada backend/database/API eksternal)
- **Bahasa**: TypeScript

## Non-Goals (batasan yang perlu diperhatikan)
- ❌ Tidak ada backend, database, atau autentikasi
- ❌ Tidak ada sinkronisasi multi-device (data hanya tersimpan di browser local)
- ❌ Tidak perlu dukungan multi-user
- ✅ Semua logic CRUD dan statistik dihitung di client-side dari data localStorage

## Core Features
1. **CRUD Item** — tambah, edit, hapus item tracking
2. **Status Tracking** — 3 status: `To Learn` → `In Progress` → `Done`
3. **Kategori/Tag** — Frontend, Backend, Mobile, System Design, dll (bisa custom tambah kategori)
4. **Prioritas** — High / Medium / Low
5. **Catatan & Link Resource** — field bebas per item untuk catatan atau link dokumentasi/video/repo
6. **Filter & Search** — filter berdasarkan status, kategori, prioritas; search berdasarkan judul/catatan
7. **Sort** — terbaru, prioritas tertinggi, abjad
8. **Statistik Dashboard**:
   - Ringkasan jumlah item per status
   - Progress bar keseluruhan (%)
   - Chart sederhana (jumlah item per kategori / selesai per bulan)
   - Streak counter (hari aktif berturut-turut)
9. **Quote/Motivasi Acak** — muncul di dashboard
10. **Micro-interaction** — animasi ringan (contoh: confetti saat item ditandai `Done`)

## Data Model (localStorage schema)

```ts
type Priority = "low" | "medium" | "high";
type Status = "to-learn" | "in-progress" | "done";

interface TrackItem {
  id: string;
  title: string;
  description?: string;
  resourceLink?: string;
  category: string;
  priority: Priority;
  status: Status;
  createdAt: string; // ISO date
  completedAt?: string; // ISO date, diisi saat status jadi "done"
}

interface AppState {
  items: TrackItem[];
  categories: string[]; // daftar kategori custom yang pernah dibuat
  lastActiveDate?: string; // dipakai untuk hitung streak
  currentStreak: number;
}
```

Key localStorage yang disarankan: `crawl-tracker-data`

## Referensi Diskusi
File ini dibuat berdasarkan hasil diskusi kebutuhan fitur bersama user sebelum development dimulai. Detail visual ada di `design.md`, breakdown pengerjaan ada di `task.md`.
