# Design.md — Tema & Visual Guideline

## Mood & Vibe
**Playful & Energizing** — web ini harus terasa ringan, ceria, dan bikin semangat tiap kali dibuka. Bukan tracker yang terkesan kaku/serius kayak tools produktivitas kantoran, tapi lebih ke suasana yang menyenangkan buat dipakai tiap hari.

Kata kunci: *fun, colorful, encouraging, cozy, sedikit playful-cartoonish.*

## Color Palette

| Warna | Hex | Peran |
|---|---|---|
| Light Cyan | `#E0FBFC` | Background utama / surface terang |
| Turquoise | `#64DFDF` | Warna aksen utama (button, highlight, progress bar) |
| Soft Coral (aksen tambahan) | `#FF9F80` | Aksen prioritas High / notifikasi hangat |
| Soft Yellow (aksen tambahan) | `#FFD972` | Aksen prioritas Medium / bintang/reward |
| Mint Green (aksen tambahan) | `#8FE3B8` | Status "Done" / sukses |
| Deep Navy/Slate (teks) | `#1B2A3A` (kira-kira, sesuaikan kontras) | Warna teks utama supaya kontras cukup di atas background cyan muda |

> Catatan: dua warna aksen tambahan (coral, yellow, mint) dipakai supaya palet gak monoton hanya cyan-turquoise, terutama buat bedain prioritas/status secara visual. Boleh disesuaikan asal tetap senada (soft pastel + 1 warna pop).

## Status & Priority Color Mapping
- **To Learn** → abu-abu netral / turquoise pucat (belum mulai)
- **In Progress** → Turquoise `#64DFDF` (lagi aktif dikerjain)
- **Done** → Mint Green `#8FE3B8` + efek confetti singkat saat pindah ke status ini

- **Priority High** → 🔴 Soft Coral `#FF9F80`
- **Priority Medium** → 🟡 Soft Yellow `#FFD972`
- **Priority Low** → 🟢 Mint/turquoise pucat

## Typography
- Font sans-serif yang friendly & rounded (contoh: `Poppins`, `Quicksand`, atau `Nunito`) — hindari font yang terlalu formal/serius seperti Times/Georgia
- Heading tebal & agak besar biar terasa playful
- Body text tetap readable, jangan terlalu dekoratif

## UI Elements & Component Style
- **Border radius besar** (rounded-xl / rounded-2xl) di card, button, input — hindari sudut tajam
- **Shadow lembut** (soft drop shadow), bukan shadow tajam ala neo-brutalism
- **Badge/chip** berwarna-warni untuk kategori dan prioritas
- **Emoji** dipakai secukupnya di kategori, status, dan pesan motivasi (jangan berlebihan sampai norak)
- **Empty state** yang friendly, misal ilustrasi/emoji + copy yang menyemangati ("Belum ada yang di-track nih, yuk mulai belajar sesuatu! 🚀")

## Mascot Idea (opsional, bisa didiskusikan lagi)
Kura-kura kecil sebagai maskot yang merepresentasikan progress — misalnya posisi kura-kura di sebuah track/garis bergerak maju sesuai persentase item yang sudah `Done`. Cocok dengan motto pemilik project: *"I may be slow, but I never stop crawling forward 🐢"*

## Micro-interactions
- Confetti/burst animation kecil saat item ditandai `Done`
- Transisi halus (fade/slide) saat filter atau pindah status
- Progress bar dengan animasi mengisi (bukan langsung penuh instan)
- Hover state ringan di card/button (scale kecil atau shadow bertambah)

## Layout Structure (high-level)
1. **Header** — judul app, quote motivasi harian, streak counter
2. **Stats Summary** — ringkasan jumlah item per status + progress bar keseluruhan
3. **Toolbar** — search bar, filter (status/kategori/prioritas), sort, tombol "Tambah Item"
4. **List Area** — daftar item dalam bentuk card, menampilkan judul, kategori, prioritas, status, dan quick action (ubah status, edit, hapus)
5. **Modal/Form** — form tambah/edit item (judul, deskripsi, link, kategori, prioritas)

## Dark Mode
Tidak wajib di versi awal, tapi struktur warna sebaiknya disiapkan supaya gampang ditambah dark mode di kemudian hari (gunakan CSS variables / Tailwind theme extend, jangan hardcode hex di tiap komponen).
