# Task.md — Checklist Pengerjaan

> Centang `[x]` setiap task yang sudah selesai. Kerjakan berurutan per phase untuk hasil yang lebih terstruktur.

## Phase 0 — Setup Project
- [ ] Init project Next.js (App Router) + TypeScript
- [ ] Install & konfigurasi Tailwind CSS
- [ ] Setup struktur folder (`app/`, `components/`, `lib/`, `types/`, `hooks/`)
- [ ] Setup font custom (Poppins/Quicksand/Nunito) via `next/font`
- [ ] Konfigurasi warna tema di `tailwind.config` sesuai `design.md` (extend palette + CSS variables)

## Phase 1 — Data Layer
- [ ] Buat type definitions (`TrackItem`, `AppState`, `Priority`, `Status`) sesuai `project.md`
- [ ] Buat utility functions untuk baca/tulis localStorage (`getItems`, `saveItems`, dll)
- [ ] Buat custom hook `useTracker()` untuk mengelola state items (CRUD + sinkron ke localStorage)
- [ ] Buat logic hitung streak (`currentStreak`, `lastActiveDate`)
- [ ] Buat kumpulan quote motivasi (array statis) + fungsi ambil random

## Phase 2 — Komponen UI Dasar
- [ ] Komponen `Button` (varian: primary/secondary/ghost) sesuai style rounded + shadow lembut
- [ ] Komponen `Badge/Chip` untuk kategori & prioritas dengan warna dinamis
- [ ] Komponen `Card` untuk item list
- [ ] Komponen `Modal` untuk form tambah/edit
- [ ] Komponen `EmptyState` (ilustrasi/emoji + copy menyemangati)

## Phase 3 — List & Filter
- [ ] Halaman utama menampilkan list item dari localStorage
- [ ] Search bar (filter by judul/deskripsi)
- [ ] Filter by status, kategori, prioritas (bisa dikombinasi)
- [ ] Sort (terbaru, prioritas tertinggi, abjad)
- [ ] Quick action di tiap card: ubah status, edit, hapus

## Phase 4 — Form Tambah/Edit Item
- [ ] Form input: judul, deskripsi, link resource, kategori (select + opsi tambah kategori baru), prioritas, status awal
- [ ] Validasi input dasar (judul wajib diisi)
- [ ] Simpan ke localStorage via `useTracker()`
- [ ] Handle edit item existing (prefill form)

## Phase 5 — Statistik & Motivasi
- [ ] Komponen Stats Summary (jumlah item per status)
- [ ] Progress bar keseluruhan (% item `Done` dari total)
- [ ] Chart sederhana (jumlah item per kategori / selesai per bulan) — bisa pakai Recharts
- [ ] Tampilkan streak counter di header
- [ ] Tampilkan quote motivasi random di header/dashboard

## Phase 6 — Polish & Micro-interactions
- [ ] Animasi confetti saat item ditandai `Done`
- [ ] Transisi halus saat filter/pindah status
- [ ] Animasi progress bar mengisi
- [ ] Hover state di card & button
- [ ] Responsive check (mobile, tablet, desktop)
- [ ] (Opsional) Implementasi maskot kura-kura yang bergerak sesuai progress

## Phase 7 — Finishing
- [ ] Cek edge case: localStorage kosong/pertama kali dibuka
- [ ] Cek edge case: hapus semua item
- [ ] Review konsistensi warna & style sesuai `design.md`
- [ ] Testing manual seluruh fitur CRUD + filter + statistik
- [ ] Build & deploy (misal ke Vercel)
